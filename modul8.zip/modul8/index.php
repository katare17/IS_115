<!DOCTYPE html>
<html>
    <head>
        <?php
            include "inc/head.inc.php";
        ?>
    </head>
    <body>
        <?php include "inc/navbarController.php"; ?>
        <div class="centered-content">
            <h1>Velkommen til søknadssystemet vårt!</h1>
        </div>
    </body>
</html>