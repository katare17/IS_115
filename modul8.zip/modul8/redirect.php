<!DOCTYPE html>
<html>
    <head>
        <?php include "inc/head.inc.php";
        ?>
    </head>
    <body>
        <?php include "inc/navbarController.php"; ?>
        <h1> Du må være innlogget for å se denne siden:</h1>
        <div>
            <a href="loggInn.php" class="btn">Logg inn</a>
            <a href="registrering.php" class="btn">Registrer deg</a>
        </div>
    </body>
</html>